const express = require('express');
const cors = require('cors');
const app = express();
const port = 4000;

app.use(cors());

const data = [
  { id: 1, title: "Title 1", description: "Description 1" },
  { id: 2, title: "Title 2", description: "Description 2" }
];
app.get('', (req, res) => {
  res.send("this is home page");
});

app.get('/api', (req, res) => {
  res.json(data);
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
